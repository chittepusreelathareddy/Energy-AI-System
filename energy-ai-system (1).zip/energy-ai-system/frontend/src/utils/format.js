export const formatDateTime = (value) => (value ? new Date(value).toLocaleString() : '\u2014');

export const formatHour = (value) => (value ? new Date(value).toLocaleTimeString([], { hour: 'numeric' }) : '\u2014');

export const formatKwh = (value) => (value === null || value === undefined ? '\u2014' : `${Number(value).toFixed(2)} kWh`);

export const formatKw = (value) => (value === null || value === undefined ? '\u2014' : `${Number(value).toFixed(1)} kW`);

/**
 * Given a list of {timestamp, predicted_kwh} forecast points, finds the
 * contiguous block of highest-demand hours and returns a display string
 * like "6 PM \u2013 9 PM" (or "6 PM" if it's a single hour, or a short list
 * if the peak hours aren't contiguous).
 */
export const computePeakWindow = (points) => {
  if (!points || points.length === 0) return '\u2014';

  const sorted = [...points].sort((a, b) => b.predicted_kwh - a.predicted_kwh);
  const topCount = Math.max(1, Math.round(points.length * 0.15)); // top ~15% of hours
  const topHours = sorted.slice(0, topCount).map((p) => new Date(p.timestamp).getHours());
  const uniqueHours = [...new Set(topHours)].sort((a, b) => a - b);

  const label = (h) => {
    const d = new Date();
    d.setHours(h, 0, 0, 0);
    return d.toLocaleTimeString([], { hour: 'numeric' }).replace(' ', '').toUpperCase();
  };

  // Find the longest contiguous run of hours within the top set
  let bestStart = uniqueHours[0];
  let bestEnd = uniqueHours[0];
  let curStart = uniqueHours[0];
  for (let i = 1; i < uniqueHours.length; i++) {
    if (uniqueHours[i] === uniqueHours[i - 1] + 1) {
      if (uniqueHours[i] - curStart > bestEnd - bestStart) {
        bestStart = curStart;
        bestEnd = uniqueHours[i];
      }
    } else {
      curStart = uniqueHours[i];
    }
  }

  if (bestStart === bestEnd) return label(bestStart);
  return `${label(bestStart)} \u2013 ${label(bestEnd + 1)}`;
};
