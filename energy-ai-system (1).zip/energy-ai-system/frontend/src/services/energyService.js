import api from './api.js';

export const getSummary = () => api.get('/api/summary').then((r) => r.data);
export const getForecast = (horizon = 24) => api.get(`/api/forecast?horizon=${horizon}`).then((r) => r.data);
export const getHistory = (hours = 168) => api.get(`/api/readings/history?hours=${hours}`).then((r) => r.data);
export const getAnomalies = (limit = 50) => api.get(`/api/anomalies?limit=${limit}`).then((r) => r.data);
export const getRecommendations = () => api.get('/api/recommendations').then((r) => r.data);
export const getModelMetrics = () => api.get('/api/models/metrics').then((r) => r.data);
export const retrainModels = () => api.post('/api/models/retrain').then((r) => r.data);
export const submitReading = (payload) => api.post('/api/readings', payload).then((r) => r.data);
