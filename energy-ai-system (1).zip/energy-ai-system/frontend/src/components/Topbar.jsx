import { useState } from 'react';
import { Menu, Moon, Sun, Play } from 'lucide-react';
import toast from 'react-hot-toast';
import useTheme from '../hooks/useTheme.js';
import { submitReading } from '../services/energyService.js';

const Topbar = ({ onMenuClick, onDataChanged }) => {
  const { darkMode, toggleDarkMode } = useTheme();
  const [simulating, setSimulating] = useState(false);

  const handleSimulate = async () => {
    setSimulating(true);
    try {
      const hour = new Date().getHours();
      const base = 1.0 + 0.7 * Math.max(0, 1 - Math.abs(hour - 8) / 3) + 1.0 * Math.max(0, 1 - Math.abs(hour - 19) / 3);
      const consumption = Number((base * (0.85 + Math.random() * 0.3)).toFixed(3));
      const result = await submitReading({
        consumption_kwh: consumption,
        voltage: Number((230 + (Math.random() * 4 - 2)).toFixed(2)),
        current: Number(((consumption * 1000) / 230).toFixed(3)),
        temperature_c: Number((20 + (Math.random() * 6 - 3)).toFixed(2)),
        source: 'simulated',
      });
      if (result.anomaly_detected) {
        toast.error(`Anomaly detected: ${consumption} kWh reading!`);
      } else {
        toast.success(`Simulated reading recorded: ${consumption} kWh`);
      }
      onDataChanged?.();
    } catch {
      toast.error('Could not submit simulated reading');
    } finally {
      setSimulating(false);
    }
  };

  return (
    <header className="glass-card mb-6 flex items-center justify-between rounded-2xl px-4 py-3 sm:px-6">
      <button onClick={onMenuClick} className="text-slate-600 dark:text-slate-300 lg:hidden">
        <Menu size={22} />
      </button>

      <div className="hidden text-sm text-slate-500 dark:text-slate-400 lg:block">
        AI-Based Energy Consumption Prediction and Optimization
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <button onClick={handleSimulate} disabled={simulating} className="btn-primary flex items-center gap-1.5">
          <Play size={15} /> <span className="hidden sm:inline">{simulating ? 'Sending...' : 'Simulate Reading'}</span>
        </button>
        <button onClick={toggleDarkMode} className="btn-secondary !px-2 !py-2" title="Toggle dark mode">
          {darkMode ? <Sun size={16} /> : <Moon size={16} />}
        </button>
      </div>
    </header>
  );
};

export default Topbar;
