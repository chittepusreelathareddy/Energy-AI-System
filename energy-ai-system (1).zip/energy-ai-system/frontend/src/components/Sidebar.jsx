import { NavLink } from 'react-router-dom';
import { LayoutDashboard, History, AlertTriangle, Lightbulb, BarChart3, Zap, X } from 'lucide-react';

const LINKS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/history', label: 'Consumption History', icon: History },
  { to: '/anomalies', label: 'Anomalies', icon: AlertTriangle },
  { to: '/recommendations', label: 'Recommendations', icon: Lightbulb },
  { to: '/models', label: 'Model Comparison', icon: BarChart3 },
];

const Sidebar = ({ open, onClose }) => (
  <>
    {open && <div className="fixed inset-0 z-30 bg-black/30 lg:hidden" onClick={onClose} />}
    <aside
      className={`glass-card fixed inset-y-4 left-4 z-40 w-64 rounded-2xl p-4 transition-transform duration-200
        lg:sticky lg:top-4 lg:translate-x-0
        ${open ? 'translate-x-0' : '-translate-x-[calc(100%+2rem)]'}`}
    >
      <div className="mb-6 flex items-center justify-between px-2">
        <span className="flex items-center gap-2 text-base font-bold text-primary-700 dark:text-primary-400">
          <Zap size={20} /> EnergyAI
        </span>
        <button onClick={onClose} className="text-slate-500 lg:hidden"><X size={20} /></button>
      </div>

      <nav className="flex flex-col gap-1">
        {LINKS.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            onClick={onClose}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                isActive
                  ? 'bg-primary-600 text-white shadow'
                  : 'text-slate-600 hover:bg-primary-50 dark:text-slate-300 dark:hover:bg-white/10'
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  </>
);

export default Sidebar;
