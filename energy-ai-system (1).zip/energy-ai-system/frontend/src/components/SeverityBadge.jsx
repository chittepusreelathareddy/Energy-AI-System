const STYLES = {
  low: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-500/20 dark:text-yellow-300',
  medium: 'bg-orange-100 text-orange-800 dark:bg-orange-500/20 dark:text-orange-300',
  high: 'bg-red-100 text-red-800 dark:bg-red-500/20 dark:text-red-300',
};

const SeverityBadge = ({ severity }) => (
  <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold capitalize ${STYLES[severity] || STYLES.low}`}>
    {severity}
  </span>
);

export default SeverityBadge;
