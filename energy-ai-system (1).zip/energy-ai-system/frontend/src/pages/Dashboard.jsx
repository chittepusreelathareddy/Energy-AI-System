// Main dashboard: a single consolidated view matching the target layout -
// three stat cards, one consumption graph (history flowing into forecast),
// a peak-hours / recommendations row, and an anomaly alert feed. Deeper
// drill-down (full history table, full anomaly log, model metrics) lives on
// their own pages, linked from the sidebar.
import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, Filler,
} from 'chart.js';
import { Activity, TrendingUp, Zap, Clock, Lightbulb, AlertTriangle, ArrowRight } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import Spinner from '../components/Spinner.jsx';
import SeverityBadge from '../components/SeverityBadge.jsx';
import { getSummary, getForecast, getHistory, getAnomalies, getRecommendations } from '../services/energyService.js';
import { formatDateTime, formatKw, formatKwh, computePeakWindow } from '../utils/format.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, Filler);

const RECOMMENDATION_LABELS = {
  peak_shift: 'Shift usage',
  threshold_alert: 'Reduce consumption',
  efficiency: 'Efficiency tip',
};

const Dashboard = () => {
  const [summary, setSummary] = useState(null);
  const [forecast, setForecast] = useState(null);
  const [history, setHistory] = useState([]);
  const [anomalies, setAnomalies] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const [summaryData, forecastData, historyData, anomalyData, recData] = await Promise.all([
        getSummary(),
        getForecast(24).catch(() => null),
        getHistory(24).catch(() => []),
        getAnomalies(5).catch(() => []),
        getRecommendations().catch(() => []),
      ]);
      setSummary(summaryData);
      setForecast(forecastData);
      setHistory(historyData);
      setAnomalies(anomalyData);
      setRecommendations(recData);
    } catch {
      toast.error('Could not load dashboard data. Is the backend running and seeded?');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const interval = setInterval(load, 15000);
    return () => clearInterval(interval);
  }, [load]);

  if (loading) {
    return (
      <DashboardLayout onDataChanged={load}>
        <Spinner />
      </DashboardLayout>
    );
  }

  // One continuous graph: recent actual history flowing into the forecast,
  // joined at the current moment so the line reads as a single trend.
  const historyLabels = history.map((h) => new Date(h.timestamp).toLocaleTimeString([], { hour: 'numeric' }));
  const forecastLabels = forecast ? forecast.points.map((p) => new Date(p.timestamp).toLocaleTimeString([], { hour: 'numeric' })) : [];
  const combinedLabels = [...historyLabels, ...forecastLabels];

  const actualData = [...history.map((h) => h.consumption_kwh), ...forecastLabels.map(() => null)];
  const predictedData = [...history.map(() => null), ...(forecast ? forecast.points.map((p) => p.predicted_kwh) : [])];
  // Bridge the gap: make the forecast line start exactly where actual ends
  if (history.length > 0 && forecast?.points?.length > 0) {
    predictedData[history.length - 1] = history[history.length - 1].consumption_kwh;
  }

  const chartData = {
    labels: combinedLabels,
    datasets: [
      {
        label: 'Actual (kWh)',
        data: actualData,
        borderColor: '#16a34a',
        backgroundColor: 'rgba(34,197,94,0.12)',
        tension: 0.3,
        fill: true,
        pointRadius: 0,
        spanGaps: false,
      },
      {
        label: 'Predicted (kWh)',
        data: predictedData,
        borderColor: '#2563eb',
        borderDash: [6, 4],
        backgroundColor: 'rgba(37,99,235,0.08)',
        tension: 0.3,
        fill: true,
        pointRadius: 0,
        spanGaps: false,
      },
    ],
  };

  const peakWindow = forecast ? computePeakWindow(forecast.points) : '\u2014';

  return (
    <DashboardLayout onDataChanged={load}>
      {/* Title banner */}
      <div className="glass-card mb-6 flex items-center gap-3 px-6 py-5">
        <div className="rounded-xl bg-primary-600 p-2.5 text-white">
          <Zap size={22} />
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100">Energy AI Monitoring System</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {summary?.active_model ? `Active model: ${summary.active_model}` : 'No model trained yet'}
            {summary?.latest_reading_time && ` \u00b7 Last reading ${formatDateTime(summary.latest_reading_time)}`}
          </p>
        </div>
      </div>

      {/* Three stat cards: Current | Predicted | Today's */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatBlock icon={Activity} label="Current" value={formatKw(summary?.latest_reading_kwh)} accent="text-primary-600" />
        <StatBlock icon={TrendingUp} label="Predicted (next hour)" value={formatKw(forecast?.points?.[0]?.predicted_kwh)} accent="text-blue-600" />
        <StatBlock icon={Clock} label="Today's Usage" value={formatKwh(summary?.today_consumption_kwh)} accent="text-amber-600" />
      </div>

      {/* Consumption graph */}
      <div className="glass-card mb-6 p-6">
        <h2 className="mb-4 font-semibold text-slate-800 dark:text-slate-100">Energy Consumption Graph</h2>
        {history.length > 0 || forecast ? (
          <Line
            data={chartData}
            options={{
              responsive: true,
              interaction: { mode: 'index', intersect: false },
              plugins: { legend: { display: true, position: 'bottom', labels: { boxWidth: 12 } } },
              scales: { y: { beginAtZero: true }, x: { grid: { display: false } } },
            }}
          />
        ) : (
          <p className="py-16 text-center text-sm text-slate-400 dark:text-slate-500">
            No data yet \u2014 click "Simulate Reading" or run the training script.
          </p>
        )}
      </div>

      {/* Peak Hours | AI Recommendations */}
      <div className="mb-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="glass-card p-6">
          <div className="mb-3 flex items-center gap-2">
            <Clock size={18} className="text-primary-600 dark:text-primary-400" />
            <h2 className="font-semibold text-slate-800 dark:text-slate-100">Peak Hours</h2>
          </div>
          <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{peakWindow}</p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Predicted highest-demand window, next 24h</p>
        </div>

        <div className="glass-card p-6">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lightbulb size={18} className="text-primary-600 dark:text-primary-400" />
              <h2 className="font-semibold text-slate-800 dark:text-slate-100">AI Recommendations</h2>
            </div>
            <Link to="/recommendations" className="flex items-center gap-1 text-xs text-primary-600 hover:underline dark:text-primary-400">
              View all <ArrowRight size={12} />
            </Link>
          </div>
          {recommendations.length > 0 ? (
            <ul className="space-y-2">
              {recommendations.slice(0, 3).map((r) => (
                <li key={r.id} className="text-sm">
                  <span className="font-medium text-slate-800 dark:text-slate-100">
                    {RECOMMENDATION_LABELS[r.category] || r.category}
                  </span>
                  <span className="block text-xs text-slate-500 dark:text-slate-400">{r.message}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate-400 dark:text-slate-500">No recommendations yet.</p>
          )}
        </div>
      </div>

      {/* Anomaly Alerts */}
      <div className="glass-card p-6">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle size={18} className="text-red-500" />
            <h2 className="font-semibold text-slate-800 dark:text-slate-100">Anomaly Alerts</h2>
          </div>
          <Link to="/anomalies" className="flex items-center gap-1 text-xs text-primary-600 hover:underline dark:text-primary-400">
            View all <ArrowRight size={12} />
          </Link>
        </div>
        {anomalies.length > 0 ? (
          <ul className="space-y-3">
            {anomalies.map((a) => (
              <li key={a.id} className="flex items-start gap-3">
                <SeverityBadge severity={a.severity} />
                <div className="text-sm text-slate-700 dark:text-slate-200">
                  {a.message}
                  <span className="ml-2 text-xs text-slate-400 dark:text-slate-500">{formatDateTime(a.timestamp)}</span>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-slate-400 dark:text-slate-500">No anomalies detected recently.</p>
        )}
      </div>
    </DashboardLayout>
  );
};

const StatBlock = ({ icon: Icon, label, value, accent }) => (
  <div className="glass-card p-5 text-center">
    <div className={`mx-auto mb-2 w-fit rounded-xl bg-primary-50 p-3 dark:bg-white/10 ${accent}`}>
      <Icon size={22} />
    </div>
    <p className="text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">{label}</p>
    <p className="mt-1 text-2xl font-bold text-slate-800 dark:text-slate-100">{value}</p>
  </div>
);

export default Dashboard;
