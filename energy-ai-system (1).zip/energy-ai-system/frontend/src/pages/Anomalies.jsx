import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { AlertTriangle } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import Spinner from '../components/Spinner.jsx';
import SeverityBadge from '../components/SeverityBadge.jsx';
import { getAnomalies } from '../services/energyService.js';
import { formatDateTime, formatKwh } from '../utils/format.js';

const Anomalies = () => {
  const [anomalies, setAnomalies] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    getAnomalies(100)
      .then(setAnomalies)
      .catch(() => toast.error('Could not load anomalies'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  return (
    <DashboardLayout onDataChanged={load}>
      <h1 className="mb-1 text-2xl font-bold text-slate-800 dark:text-slate-100">Anomalies</h1>
      <p className="mb-6 text-sm text-slate-500 dark:text-slate-400">
        Readings where actual consumption deviated significantly from the model's expectation for that hour.
      </p>

      {loading ? (
        <Spinner />
      ) : anomalies.length === 0 ? (
        <div className="glass-card flex flex-col items-center gap-2 p-12 text-center">
          <AlertTriangle className="text-slate-300 dark:text-slate-600" size={40} />
          <p className="text-slate-500 dark:text-slate-400">No anomalies detected yet.</p>
          <p className="text-xs text-slate-400 dark:text-slate-500">
            Try the "Simulate Reading" button a few times, or wait for a naturally unusual reading to come in.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {anomalies.map((a) => (
            <div key={a.id} className="glass-card flex flex-wrap items-start justify-between gap-3 p-5">
              <div>
                <div className="mb-1 flex items-center gap-2">
                  <SeverityBadge severity={a.severity} />
                  <span className="text-xs text-slate-400 dark:text-slate-500">{formatDateTime(a.timestamp)}</span>
                </div>
                <p className="text-sm text-slate-700 dark:text-slate-200">{a.message}</p>
              </div>
              <div className="text-right text-xs text-slate-500 dark:text-slate-400">
                <p>Actual: <strong>{formatKwh(a.actual_kwh)}</strong></p>
                <p>Expected: <strong>{formatKwh(a.predicted_kwh)}</strong></p>
              </div>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
};

export default Anomalies;
