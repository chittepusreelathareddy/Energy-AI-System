import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Lightbulb, TrendingDown, AlertCircle, Leaf, RefreshCw } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import Spinner from '../components/Spinner.jsx';
import { getRecommendations } from '../services/energyService.js';
import { formatDateTime } from '../utils/format.js';

const ICONS = {
  peak_shift: TrendingDown,
  threshold_alert: AlertCircle,
  efficiency: Leaf,
};

const LABELS = {
  peak_shift: 'Peak Shift',
  threshold_alert: 'Budget Alert',
  efficiency: 'Efficiency Tip',
};

const Recommendations = () => {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    getRecommendations()
      .then(setRecommendations)
      .catch(() => toast.error('Could not load recommendations. Has the model been trained yet?'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  return (
    <DashboardLayout onDataChanged={load}>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Recommendations</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Generated fresh from the current 24-hour forecast.</p>
        </div>
        <button onClick={load} className="btn-secondary flex items-center gap-2">
          <RefreshCw size={15} /> Refresh
        </button>
      </div>

      {loading ? (
        <Spinner />
      ) : recommendations.length === 0 ? (
        <div className="glass-card flex flex-col items-center gap-2 p-12 text-center">
          <Lightbulb className="text-slate-300 dark:text-slate-600" size={40} />
          <p className="text-slate-500 dark:text-slate-400">No recommendations right now.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {recommendations.map((r) => {
            const Icon = ICONS[r.category] || Lightbulb;
            return (
              <div key={r.id} className="glass-card p-5">
                <div className="mb-2 flex items-center gap-2">
                  <div className="rounded-lg bg-primary-50 p-2 text-primary-600 dark:bg-white/10 dark:text-primary-400">
                    <Icon size={18} />
                  </div>
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                    {LABELS[r.category] || r.category}
                  </span>
                </div>
                <p className="text-sm text-slate-700 dark:text-slate-200">{r.message}</p>
                <p className="mt-3 text-xs text-slate-400 dark:text-slate-500">{formatDateTime(r.created_at)}</p>
              </div>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
};

export default Recommendations;
