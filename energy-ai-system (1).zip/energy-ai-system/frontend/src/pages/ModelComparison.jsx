import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { RefreshCw, Trophy } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import Spinner from '../components/Spinner.jsx';
import { getModelMetrics, retrainModels } from '../services/energyService.js';
import { formatDateTime } from '../utils/format.js';

const METRIC_HELP = {
  mae: 'Mean Absolute Error \u2014 average error in kWh. Lower is better.',
  rmse: 'Root Mean Squared Error \u2014 penalizes large misses more. Lower is better.',
  mape: 'Mean Absolute Percentage Error \u2014 error as a % of actual usage. Lower is better.',
  r2: 'R\u00b2 \u2014 how much variance the model explains. Higher (closer to 1) is better.',
};

const ModelComparison = () => {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [retraining, setRetraining] = useState(false);

  const load = () => {
    setLoading(true);
    getModelMetrics()
      .then(setMetrics)
      .catch(() => toast.error('No trained models found yet. Run scripts/train_models.py first.'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleRetrain = async () => {
    setRetraining(true);
    try {
      await retrainModels();
      toast.success('Models retrained successfully');
      load();
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Retraining failed');
    } finally {
      setRetraining(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Model Comparison</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Candidate forecasting models, evaluated on the same held-out test set.
          </p>
        </div>
        <button onClick={handleRetrain} disabled={retraining} className="btn-primary flex items-center gap-2">
          <RefreshCw size={15} className={retraining ? 'animate-spin' : ''} />
          {retraining ? 'Retraining...' : 'Retrain on latest data'}
        </button>
      </div>

      {loading ? (
        <Spinner />
      ) : !metrics ? (
        <div className="glass-card p-8 text-center text-sm text-slate-500 dark:text-slate-400">
          No training run found yet. Run <code className="rounded bg-slate-100 px-1.5 py-0.5 dark:bg-white/10">python scripts/train_models.py</code> in the backend first.
        </div>
      ) : (
        <>
          <div className="glass-card mb-6 overflow-x-auto p-2">
            <table className="min-w-full text-sm">
              <thead className="text-left text-xs font-medium uppercase text-slate-500 dark:text-slate-400">
                <tr>
                  <th className="px-4 py-3">Model</th>
                  <th className="px-4 py-3">MAE</th>
                  <th className="px-4 py-3">RMSE</th>
                  <th className="px-4 py-3">MAPE</th>
                  <th className="px-4 py-3">R\u00b2</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/60 dark:divide-white/10">
                {Object.entries(metrics.results).map(([name, m]) => (
                  <tr key={name} className={name === metrics.active_model ? 'bg-primary-50/60 dark:bg-primary-500/10' : ''}>
                    <td className="px-4 py-3 font-medium text-slate-800 dark:text-slate-100">
                      <div className="flex items-center gap-2">
                        {name === metrics.active_model && <Trophy size={14} className="text-primary-600 dark:text-primary-400" />}
                        {name}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{m.mae.toFixed(3)}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{m.rmse.toFixed(3)}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{m.mape.toFixed(2)}%</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{m.r2.toFixed(3)}</td>
                    <td className="px-4 py-3 text-xs font-medium text-primary-600 dark:text-primary-400">
                      {name === metrics.active_model ? 'Active' : ''}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="glass-card mb-6 grid grid-cols-1 gap-3 p-5 text-xs text-slate-500 dark:text-slate-400 sm:grid-cols-2">
            {Object.entries(METRIC_HELP).map(([key, help]) => (
              <p key={key}><strong className="uppercase text-slate-600 dark:text-slate-300">{key}</strong>: {help}</p>
            ))}
          </div>

          <p className="text-xs text-slate-400 dark:text-slate-500">
            Last trained: {formatDateTime(metrics.trained_at)} &middot; {metrics.n_training_rows} training rows, {metrics.n_test_rows} test rows
          </p>
        </>
      )}
    </DashboardLayout>
  );
};

export default ModelComparison;
