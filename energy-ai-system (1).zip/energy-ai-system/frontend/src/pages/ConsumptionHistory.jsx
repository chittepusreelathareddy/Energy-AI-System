import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, Filler,
} from 'chart.js';
import DashboardLayout from '../components/DashboardLayout.jsx';
import Spinner from '../components/Spinner.jsx';
import { getHistory } from '../services/energyService.js';
import { formatDateTime, formatKwh } from '../utils/format.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, Filler);

const RANGE_OPTIONS = [
  { label: '24 hours', hours: 24 },
  { label: '3 days', hours: 72 },
  { label: '7 days', hours: 168 },
  { label: '30 days', hours: 720 },
];

const ConsumptionHistory = () => {
  const [hours, setHours] = useState(168);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getHistory(hours)
      .then(setHistory)
      .catch(() => toast.error('Could not load consumption history'))
      .finally(() => setLoading(false));
  }, [hours]);

  const chartData = {
    labels: history.map((h) => new Date(h.timestamp).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric' })),
    datasets: [{
      label: 'Consumption (kWh)',
      data: history.map((h) => h.consumption_kwh),
      borderColor: '#16a34a',
      backgroundColor: 'rgba(34,197,94,0.12)',
      tension: 0.25,
      fill: true,
      pointRadius: 0,
    }],
  };

  return (
    <DashboardLayout>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Consumption History</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Historical and simulated readings over time.</p>
        </div>
        <div className="flex gap-2">
          {RANGE_OPTIONS.map((opt) => (
            <button
              key={opt.hours}
              onClick={() => setHours(opt.hours)}
              className={hours === opt.hours ? 'btn-primary !px-3 !py-1.5 text-xs' : 'btn-secondary !px-3 !py-1.5 text-xs'}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <Spinner />
      ) : (
        <>
          <div className="glass-card mb-6 p-6">
            {history.length > 0 ? (
              <Line data={chartData} options={{ responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }} />
            ) : (
              <p className="py-16 text-center text-sm text-slate-400 dark:text-slate-500">No readings in this range.</p>
            )}
          </div>

          <div className="glass-card max-h-[420px] overflow-y-auto overflow-x-auto p-2">
            <table className="min-w-full text-sm">
              <thead className="sticky top-0 bg-white/90 text-left text-xs font-medium uppercase text-slate-500 backdrop-blur dark:bg-slate-900/90 dark:text-slate-400">
                <tr>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">Consumption</th>
                  <th className="px-4 py-3">Voltage</th>
                  <th className="px-4 py-3">Current</th>
                  <th className="px-4 py-3">Temp</th>
                  <th className="px-4 py-3">Source</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/60 dark:divide-white/10">
                {[...history].reverse().slice(0, 200).map((h) => (
                  <tr key={h.id}>
                    <td className="px-4 py-2.5 text-slate-700 dark:text-slate-200">{formatDateTime(h.timestamp)}</td>
                    <td className="px-4 py-2.5 text-slate-700 dark:text-slate-200">{formatKwh(h.consumption_kwh)}</td>
                    <td className="px-4 py-2.5 text-slate-500 dark:text-slate-400">{h.voltage ?? '\u2014'} V</td>
                    <td className="px-4 py-2.5 text-slate-500 dark:text-slate-400">{h.current ?? '\u2014'} A</td>
                    <td className="px-4 py-2.5 text-slate-500 dark:text-slate-400">{h.temperature_c ?? '\u2014'} \u00b0C</td>
                    <td className="px-4 py-2.5 capitalize text-slate-500 dark:text-slate-400">{h.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </DashboardLayout>
  );
};

export default ConsumptionHistory;
