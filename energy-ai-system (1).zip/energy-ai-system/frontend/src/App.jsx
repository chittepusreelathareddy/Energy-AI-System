import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { ThemeProvider } from './context/ThemeContext.jsx';

import Dashboard from './pages/Dashboard.jsx';
import ConsumptionHistory from './pages/ConsumptionHistory.jsx';
import Anomalies from './pages/Anomalies.jsx';
import Recommendations from './pages/Recommendations.jsx';
import ModelComparison from './pages/ModelComparison.jsx';
import NotFound from './pages/NotFound.jsx';

function App() {
  return (
    <ThemeProvider>
      <Toaster position="top-right" />
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/history" element={<ConsumptionHistory />} />
        <Route path="/anomalies" element={<Anomalies />} />
        <Route path="/recommendations" element={<Recommendations />} />
        <Route path="/models" element={<ModelComparison />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </ThemeProvider>
  );
}

export default App;
