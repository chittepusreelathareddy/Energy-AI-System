"""
SQLAlchemy ORM models: the four tables backing the whole system.

- Reading: one row per energy measurement, historical or live/simulated.
- Anomaly: a flagged reading whose actual consumption deviated too far from
  what the active forecasting model predicted for that hour.
- ModelMetric: one row per trained candidate model (Random Forest, XGBoost,
  ...), storing its evaluation metrics and whether it's the currently active
  ("deployed") model.
- Recommendation: a generated optimization/efficiency suggestion, derived
  from the latest forecast.
"""
from datetime import datetime

from sqlalchemy import Column, Integer, Float, String, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship

from app.database import Base


class Reading(Base):
    __tablename__ = "readings"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, unique=True, index=True, nullable=False)
    consumption_kwh = Column(Float, nullable=False)
    voltage = Column(Float, nullable=True)
    current = Column(Float, nullable=True)
    temperature_c = Column(Float, nullable=True)
    source = Column(String(20), default="historical")  # historical | simulated | live
    created_at = Column(DateTime, default=datetime.utcnow)


class Anomaly(Base):
    __tablename__ = "anomalies"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, index=True, nullable=False)
    actual_kwh = Column(Float, nullable=False)
    predicted_kwh = Column(Float, nullable=False)
    residual = Column(Float, nullable=False)
    severity = Column(String(10), default="medium")  # low | medium | high
    message = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class ModelMetric(Base):
    __tablename__ = "model_metrics"

    id = Column(Integer, primary_key=True, index=True)
    model_name = Column(String(50), nullable=False)
    mae = Column(Float, nullable=False)
    rmse = Column(Float, nullable=False)
    mape = Column(Float, nullable=False)
    r2 = Column(Float, nullable=False)
    is_active = Column(Boolean, default=False)
    trained_at = Column(DateTime, default=datetime.utcnow)


class Recommendation(Base):
    __tablename__ = "recommendations"

    id = Column(Integer, primary_key=True, index=True)
    category = Column(String(30), nullable=False)  # peak_shift | threshold_alert | efficiency | anomaly_followup
    message = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
