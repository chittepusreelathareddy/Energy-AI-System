"""
Central application settings, loaded from environment variables / .env.
Using pydantic-settings means every setting is validated and typed once,
instead of scattering os.getenv() calls throughout the codebase.
"""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "sqlite:///./energy_ai.db"
    client_url: str = "http://localhost:5173"
    device_api_key: str = "replace_this_with_a_long_random_device_key"
    forecast_horizon_hours: int = 24
    daily_budget_kwh: float | None = 30.0

    class Config:
        env_file = ".env"


settings = Settings()
