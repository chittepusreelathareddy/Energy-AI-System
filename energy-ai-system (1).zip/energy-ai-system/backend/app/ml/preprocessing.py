"""
Shared feature-engineering logic used by both the training pipeline
(app/ml/train.py) and the forecasting pipeline (app/ml/forecast.py). Keeping
this in one place guarantees the features a model sees at prediction time are
built exactly the same way as the features it was trained on.
"""
import numpy as np
import pandas as pd

# Lag features: how many hours back to look when predicting the current hour.
# 1h captures short-term momentum, 24h captures "same time yesterday", and
# 168h (7*24) captures "same time last week" - a standard trio for hourly
# load forecasting.
LAG_HOURS = [1, 24, 168]
ROLLING_WINDOWS = [24]  # 24h rolling mean smooths out hour-to-hour noise

FEATURE_COLUMNS = (
    ["hour", "day_of_week", "is_weekend", "month", "temperature_c"]
    + [f"lag_{h}h" for h in LAG_HOURS]
    + [f"rolling_mean_{w}h" for w in ROLLING_WINDOWS]
)


def clean_readings(df: pd.DataFrame) -> pd.DataFrame:
    """
    Basic cleaning: ensure chronological order, drop exact-duplicate
    timestamps, and fill small gaps in consumption/temperature via linear
    interpolation (real smart-meter feeds routinely have brief dropouts).
    """
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df = df.sort_values("timestamp").drop_duplicates(subset="timestamp")
    df = df.set_index("timestamp")

    # Reindex onto a complete hourly grid so lag/rolling features are
    # well-defined even if some hours are missing from the raw data.
    full_range = pd.date_range(df.index.min(), df.index.max(), freq="h")
    df = df.reindex(full_range)
    df.index.name = "timestamp"

    for col in ["consumption_kwh", "temperature_c", "voltage", "current"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").interpolate(method="linear").bfill().ffill()

    return df.reset_index()


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["hour"] = df["timestamp"].dt.hour
    df["day_of_week"] = df["timestamp"].dt.dayofweek
    df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)
    df["month"] = df["timestamp"].dt.month
    return df


def add_lag_and_rolling_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for h in LAG_HOURS:
        df[f"lag_{h}h"] = df["consumption_kwh"].shift(h)
    for w in ROLLING_WINDOWS:
        df[f"rolling_mean_{w}h"] = df["consumption_kwh"].shift(1).rolling(window=w, min_periods=1).mean()
    return df


def build_feature_frame(raw_df: pd.DataFrame) -> pd.DataFrame:
    """
    Full pipeline: clean -> time features -> lag/rolling features.
    Rows at the very start of the series will have NaN lag features (there's
    no "168 hours ago" for the first week of data) - callers should drop
    those before training with `.dropna(subset=FEATURE_COLUMNS)`.
    """
    df = clean_readings(raw_df)
    df = add_time_features(df)
    df = add_lag_and_rolling_features(df)
    return df


def make_training_matrix(raw_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series, pd.Series]:
    """
    Returns (X, y, timestamps) ready for model.fit(X, y), with any rows that
    don't yet have full lag history dropped.
    """
    df = build_feature_frame(raw_df)
    df = df.dropna(subset=FEATURE_COLUMNS + ["consumption_kwh"])
    X = df[FEATURE_COLUMNS]
    y = df["consumption_kwh"]
    timestamps = df["timestamp"]
    return X, y, timestamps
