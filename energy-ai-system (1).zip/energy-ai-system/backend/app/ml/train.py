"""
Trains and evaluates candidate forecasting models, then saves the
best-performing one (plus its metadata) to disk for the forecasting module
to load.

Models trained by default: Random Forest and XGBoost - both fast, robust to
the modest amount of data a first deployment will have, and require no extra
heavy dependencies. An optional LSTM baseline lives in app/ml/train_lstm.py:
it's kept separate because it needs PyTorch, a much larger install that
shouldn't be a hard requirement just to get the core system running (see the
README for how to enable it). Whichever models are available are compared
on the same chronological train/test split using MAE, RMSE, MAPE and R^2,
and the best one by MAPE is marked "active".
"""
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor

from app.ml.preprocessing import make_training_matrix, FEATURE_COLUMNS

ARTIFACT_DIR = Path(__file__).resolve().parent.parent.parent / "ml_artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

MODEL_PATH = ARTIFACT_DIR / "active_model.joblib"
METRICS_PATH = ARTIFACT_DIR / "model_metrics.json"
RESIDUAL_STATS_PATH = ARTIFACT_DIR / "residual_stats.json"

TEST_FRACTION = 0.2  # last 20% of the series, chronologically, held out for evaluation


def _mape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Mean Absolute Percentage Error, guarding against near-zero actuals."""
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    mask = y_true > 1e-6
    return float(np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100)


def _evaluate(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    return {
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "mape": _mape(y_true, y_pred),
        "r2": float(r2_score(y_true, y_pred)),
    }


def _candidate_models() -> dict:
    models = {
        "RandomForest": RandomForestRegressor(
            n_estimators=200, max_depth=12, min_samples_leaf=2,
            random_state=42, n_jobs=-1,
        ),
        "XGBoost": XGBRegressor(
            n_estimators=300, max_depth=6, learning_rate=0.05,
            subsample=0.9, colsample_bytree=0.9, random_state=42,
            n_jobs=-1,
        ),
    }

    # LSTM is optional - only included in the comparison if torch is
    # installed (see app/ml/train_lstm.py and the README).
    try:
        from app.ml.train_lstm import LSTMForecaster  # noqa: F401
        models["LSTM"] = LSTMForecaster()
    except ImportError:
        pass

    return models


def train_and_evaluate(raw_df: pd.DataFrame) -> dict:
    """
    Runs the full train/evaluate/select pipeline on a raw readings
    DataFrame (columns: timestamp, consumption_kwh, voltage, current,
    temperature_c). Returns a summary dict and writes artifacts to disk.
    """
    X, y, timestamps = make_training_matrix(raw_df)

    split_idx = int(len(X) * (1 - TEST_FRACTION))
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]

    results = {}
    fitted_models = {}

    for name, model in _candidate_models().items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        metrics = _evaluate(y_test.values, preds)
        results[name] = metrics
        fitted_models[name] = model
        print(f"  {name:<14} MAE={metrics['mae']:.3f}  RMSE={metrics['rmse']:.3f}  "
              f"MAPE={metrics['mape']:.2f}%  R2={metrics['r2']:.3f}")

    # Best model = lowest MAPE on the held-out test set
    best_name = min(results, key=lambda n: results[n]["mape"])
    best_model = fitted_models[best_name]

    # Residual stats from the *training* set, used later by the anomaly
    # detector to flag readings that deviate too far from what the model
    # would have expected.
    train_preds = best_model.predict(X_train)
    residuals = np.abs(y_train.values - train_preds)
    residual_stats = {
        "mean_abs_residual": float(residuals.mean()),
        "std_abs_residual": float(residuals.std()),
        # anomaly threshold: mean + 3 standard deviations of absolute residual
        "anomaly_threshold": float(residuals.mean() + 3 * residuals.std()),
    }

    joblib.dump({"model": best_model, "model_name": best_name, "features": FEATURE_COLUMNS}, MODEL_PATH)

    metrics_out = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "active_model": best_name,
        "n_training_rows": int(len(X_train)),
        "n_test_rows": int(len(X_test)),
        "results": results,
    }
    _write_json(METRICS_PATH, metrics_out)
    _write_json(RESIDUAL_STATS_PATH, residual_stats)

    return {"active_model": best_name, "results": results, "residual_stats": residual_stats}


def _write_json(path: Path, data: dict) -> None:
    import json
    path.write_text(json.dumps(data, indent=2))


def load_active_model():
    """Loads the currently active model bundle saved by train_and_evaluate()."""
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "No trained model found. Run `python scripts/train_models.py` first."
        )
    return joblib.load(MODEL_PATH)


if __name__ == "__main__":
    # Quick manual check: python -m app.ml.train
    from app.ml.data_generator import generate_synthetic_dataset

    print("Generating synthetic dataset...")
    df = generate_synthetic_dataset(days=400)
    print("Training and evaluating candidate models...")
    summary = train_and_evaluate(df)
    print(f"\nActive model selected: {summary['active_model']}")
