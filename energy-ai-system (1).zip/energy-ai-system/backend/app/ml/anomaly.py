"""
Anomaly detection: flags a reading whose actual consumption deviates too far
from what the active model would have predicted for that hour.

The threshold (mean + 3 standard deviations of absolute residual, computed
on the training set - see app/ml/train.py) is a simple, interpretable
starting point consistent with standard residual-based anomaly detection.
Sites with noisier consumption patterns may want to tune this threshold; see
the README's note on limitations.
"""
import json
from pathlib import Path

ARTIFACT_DIR = Path(__file__).resolve().parent.parent.parent / "ml_artifacts"
RESIDUAL_STATS_PATH = ARTIFACT_DIR / "residual_stats.json"


def _load_residual_stats() -> dict:
    if not RESIDUAL_STATS_PATH.exists():
        raise FileNotFoundError(
            "No residual stats found. Run `python scripts/train_models.py` first."
        )
    return json.loads(RESIDUAL_STATS_PATH.read_text())


def check_anomaly(actual_kwh: float, predicted_kwh: float) -> dict:
    """
    Compares one actual reading against the model's prediction for that hour
    and returns a dict describing whether it's anomalous and how severe.
    """
    stats = _load_residual_stats()
    residual = actual_kwh - predicted_kwh
    abs_residual = abs(residual)
    threshold = stats["anomaly_threshold"]

    is_anomaly = abs_residual > threshold

    if not is_anomaly:
        severity = "none"
    elif abs_residual > 2 * threshold:
        severity = "high"
    elif abs_residual > 1.5 * threshold:
        severity = "medium"
    else:
        severity = "low"

    direction = "above" if residual > 0 else "below"
    message = (
        f"Consumption ({actual_kwh:.2f} kWh) was {abs_residual:.2f} kWh {direction} the "
        f"expected {predicted_kwh:.2f} kWh for this hour, exceeding the normal variation "
        f"threshold of {threshold:.2f} kWh."
        if is_anomaly else
        f"Consumption ({actual_kwh:.2f} kWh) is within the expected range "
        f"(predicted {predicted_kwh:.2f} kWh, threshold {threshold:.2f} kWh)."
    )

    return {
        "is_anomaly": is_anomaly,
        "severity": severity,
        "residual": round(residual, 4),
        "threshold": round(threshold, 4),
        "message": message,
    }
