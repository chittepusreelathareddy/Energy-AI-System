"""
Optional LSTM forecasting baseline.

This module is intentionally NOT imported by default - app/ml/train.py only
picks it up if PyTorch is installed (`pip install torch`), since torch is a
large dependency that shouldn't be required just to run the core system.
With it installed, LSTM is automatically included as a third candidate
model alongside Random Forest and XGBoost in the comparison table.

The wrapper below exposes a scikit-learn-compatible .fit(X, y) / .predict(X)
interface so app/ml/train.py can treat it exactly like the other models,
without needing any LSTM-specific code in the training loop.
"""
import numpy as np

try:
    import torch
    import torch.nn as nn
except ImportError as exc:  # pragma: no cover - exercised only when torch is absent
    raise ImportError(
        "PyTorch is not installed. Run `pip install torch` to enable the LSTM "
        "baseline, or simply ignore this - Random Forest and XGBoost work fine "
        "without it."
    ) from exc


class _LSTMNet(nn.Module):
    def __init__(self, n_features: int, hidden_size: int = 32):
        super().__init__()
        self.lstm = nn.LSTM(input_size=n_features, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # x: (batch, seq_len=1, n_features) - each row is treated as a single
        # timestep whose lag/rolling features already encode recent history,
        # so no multi-step sequence unrolling is needed here.
        out, _ = self.lstm(x)
        return self.head(out[:, -1, :]).squeeze(-1)


class LSTMForecaster:
    """Thin scikit-learn-style wrapper around the LSTM network above."""

    def __init__(self, hidden_size: int = 32, epochs: int = 30, lr: float = 1e-3):
        self.hidden_size = hidden_size
        self.epochs = epochs
        self.lr = lr
        self.model: _LSTMNet | None = None
        self._mean = None
        self._std = None

    def fit(self, X, y):
        X_arr = np.asarray(X, dtype=np.float32)
        y_arr = np.asarray(y, dtype=np.float32)

        self._mean = X_arr.mean(axis=0)
        self._std = X_arr.std(axis=0) + 1e-6
        X_norm = (X_arr - self._mean) / self._std

        self.model = _LSTMNet(n_features=X_arr.shape[1], hidden_size=self.hidden_size)
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        loss_fn = nn.MSELoss()

        X_tensor = torch.tensor(X_norm).unsqueeze(1)  # (batch, seq_len=1, features)
        y_tensor = torch.tensor(y_arr)

        self.model.train()
        for _ in range(self.epochs):
            optimizer.zero_grad()
            preds = self.model(X_tensor)
            loss = loss_fn(preds, y_tensor)
            loss.backward()
            optimizer.step()

        return self

    def predict(self, X):
        X_arr = np.asarray(X, dtype=np.float32)
        X_norm = (X_arr - self._mean) / self._std
        X_tensor = torch.tensor(X_norm).unsqueeze(1)

        self.model.eval()
        with torch.no_grad():
            preds = self.model(X_tensor)
        return preds.numpy()
