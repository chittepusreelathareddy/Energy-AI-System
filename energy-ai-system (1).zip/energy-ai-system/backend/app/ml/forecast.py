"""
Turns the trained active model into a multi-hour-ahead forecast.

The model itself only predicts one hour at a time (it was trained to map
"features at hour t" -> "consumption at hour t"). To get a 24-hour-ahead
forecast, we predict one hour, append that prediction as a new "actual"
reading, recompute lag/rolling features including it, and predict the next
hour - repeating until the full horizon is covered. This is a standard,
simple approach to multi-step time series forecasting with a single-step
model (sometimes called recursive/autoregressive forecasting), and keeps the
whole system to one model per training run rather than needing a separate
model per forecast horizon.
"""
from datetime import timedelta

import numpy as np
import pandas as pd

from app.ml.preprocessing import build_feature_frame, FEATURE_COLUMNS
from app.ml.train import load_active_model


def forecast_next_hours(recent_readings: pd.DataFrame, horizon_hours: int = 24) -> list[dict]:
    """
    recent_readings: a DataFrame of the most recent readings (needs at least
    168 hours of history for the weekly lag feature to be meaningful; fewer
    rows will still work but early predictions will lean more on the
    daily/weekly averages available).
    horizon_hours: how many hours ahead to forecast.

    Returns a list of {"timestamp": ..., "predicted_kwh": ...} dicts.
    """
    bundle = load_active_model()
    model, model_name, features = bundle["model"], bundle["model_name"], bundle["features"]

    working_df = recent_readings[["timestamp", "consumption_kwh", "temperature_c"]].copy()
    working_df["timestamp"] = pd.to_datetime(working_df["timestamp"])

    last_timestamp = working_df["timestamp"].max()
    last_temp = working_df["temperature_c"].iloc[-1] if working_df["temperature_c"].notna().any() else 20.0

    forecast_points = []

    for step in range(1, horizon_hours + 1):
        next_timestamp = last_timestamp + timedelta(hours=step)

        # Recompute features using the working series, which now includes
        # any predictions made in earlier iterations of this loop.
        feature_frame = build_feature_frame(
            pd.concat([
                working_df,
                pd.DataFrame([{
                    "timestamp": next_timestamp,
                    "consumption_kwh": np.nan,
                    "temperature_c": last_temp,  # naive: hold temperature steady over the horizon
                }]),
            ], ignore_index=True)
        )

        row = feature_frame.iloc[[-1]][features]
        # Any still-missing lag feature (very short history) falls back to
        # the overall mean seen so far, rather than crashing on NaN.
        row = row.fillna(working_df["consumption_kwh"].mean())

        predicted_kwh = float(model.predict(row)[0])
        predicted_kwh = max(predicted_kwh, 0.0)

        forecast_points.append({"timestamp": next_timestamp, "predicted_kwh": round(predicted_kwh, 4)})

        # Feed this prediction back in as if it were an actual reading, so
        # the next iteration's lag features can see it.
        working_df = pd.concat([
            working_df,
            pd.DataFrame([{"timestamp": next_timestamp, "consumption_kwh": predicted_kwh, "temperature_c": last_temp}]),
        ], ignore_index=True)

    return forecast_points, model_name


if __name__ == "__main__":
    # Quick manual check: python -m app.ml.forecast
    # (assumes `python -m app.ml.train` has already been run)
    from app.ml.data_generator import generate_synthetic_dataset

    df = generate_synthetic_dataset(days=30)
    points, model_name = forecast_next_hours(df, horizon_hours=24)
    print(f"Forecast from model: {model_name}")
    for p in points[:5]:
        print(f"  {p['timestamp']}  ->  {p['predicted_kwh']} kWh")
    print(f"  ... ({len(points)} points total)")
