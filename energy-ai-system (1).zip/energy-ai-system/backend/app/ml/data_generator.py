"""
Synthetic household energy dataset generator.

This project is designed to work out-of-the-box with public benchmark data
(e.g. the UCI Individual Household Electric Power Consumption dataset - see
the README), but downloading and licensing a real dataset shouldn't block
anyone from trying the system. This module generates a realistic *synthetic*
hourly consumption dataset with the kind of structure real household load
data has, so the whole pipeline (preprocessing -> training -> forecasting ->
anomaly detection -> recommendations) can be exercised immediately.

Swapping in real data later just means pointing scripts/train_models.py at a
CSV with the same columns: timestamp, consumption_kwh, voltage, current,
temperature_c.
"""
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd


def generate_synthetic_dataset(
    start: datetime | None = None,
    days: int = 400,
    seed: int = 42,
    anomaly_rate: float = 0.01,
) -> pd.DataFrame:
    """
    Builds an hourly synthetic household energy dataset with:
      - a daily cycle (higher usage in morning/evening, lower overnight)
      - a weekly cycle (slightly higher usage on weekends)
      - a mild seasonal/temperature effect (more usage when it's hot or cold,
        modeling heating/cooling load)
      - random noise
      - a small fraction of injected anomalies (sudden spikes), so the
        anomaly-detection module has something real to find and the
        precision/recall evaluation in scripts/train_models.py has ground
        truth to check against
    """
    rng = np.random.default_rng(seed)
    start = start or (datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=days))
    n_hours = days * 24
    timestamps = [start + timedelta(hours=i) for i in range(n_hours)]

    hours = np.array([t.hour for t in timestamps])
    day_of_week = np.array([t.weekday() for t in timestamps])
    day_index = np.arange(n_hours) / 24.0

    # Daily shape: two bumps (morning ~7-9am, evening ~6-9pm), low overnight
    daily_pattern = (
        1.0
        + 0.6 * np.exp(-0.5 * ((hours - 8) / 1.8) ** 2)
        + 0.9 * np.exp(-0.5 * ((hours - 19) / 2.2) ** 2)
    )

    # Weekend effect: slightly higher and flatter usage
    is_weekend = (day_of_week >= 5).astype(float)
    weekend_boost = 1.0 + 0.15 * is_weekend

    # Seasonal temperature: sinusoidal over the year, plus daily swing
    seasonal_temp = 18 + 10 * np.sin(2 * np.pi * day_index / 365.0)
    daily_temp_swing = 4 * np.sin(2 * np.pi * (hours - 15) / 24.0)
    temperature_c = seasonal_temp + daily_temp_swing + rng.normal(0, 1.2, n_hours)

    # Heating/cooling load: U-shaped around a comfortable ~20C
    climate_load = 1.0 + 0.03 * np.clip(np.abs(temperature_c - 20) - 4, 0, None)

    base_kwh = 0.9  # baseline household draw (fridge, standby devices, etc.)
    consumption = (
        base_kwh
        * daily_pattern
        * weekend_boost
        * climate_load
        * (1 + rng.normal(0, 0.08, n_hours))  # multiplicative noise
    )
    consumption = np.clip(consumption, 0.05, None)

    # Voltage/current are derived so they stay physically consistent with
    # consumption (P = V * I / 1000 for kW), with small measurement noise.
    voltage = 230 + rng.normal(0, 2.5, n_hours)
    power_kw = consumption  # approximating kWh-per-hour as an average kW draw
    current = (power_kw * 1000) / voltage + rng.normal(0, 0.05, n_hours)

    # Inject a handful of anomalous spikes (e.g. a faulty appliance left on)
    is_injected_anomaly = np.zeros(n_hours, dtype=bool)
    n_anomalies = int(n_hours * anomaly_rate)
    anomaly_idx = rng.choice(n_hours, size=n_anomalies, replace=False)
    consumption[anomaly_idx] *= rng.uniform(2.5, 4.5, n_anomalies)
    is_injected_anomaly[anomaly_idx] = True

    df = pd.DataFrame({
        "timestamp": timestamps,
        "consumption_kwh": np.round(consumption, 4),
        "voltage": np.round(voltage, 2),
        "current": np.round(current, 3),
        "temperature_c": np.round(temperature_c, 2),
        "is_injected_anomaly": is_injected_anomaly,  # ground truth, for evaluation only
    })
    return df


if __name__ == "__main__":
    # Quick manual check: python -m app.ml.data_generator
    df = generate_synthetic_dataset(days=30)
    print(df.head())
    print(f"\nGenerated {len(df)} rows, {df['is_injected_anomaly'].sum()} injected anomalies")
