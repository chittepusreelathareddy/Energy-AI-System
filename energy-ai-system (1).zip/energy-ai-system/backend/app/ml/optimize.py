"""
Turns a forecast into actionable recommendations: which hours look like
peak-demand windows worth shifting load away from, and whether the
predicted daily total is on track to exceed a configured budget.

This is deliberately rule-based rather than another ML model - the outputs
need to be simple, explainable statements a non-technical user can act on
("shift laundry to 1-4pm"), not another black box on top of the forecast.
"""
from app.config import settings


def generate_recommendations(forecast_points: list[dict]) -> list[dict]:
    """
    forecast_points: list of {"timestamp": datetime, "predicted_kwh": float},
    as returned by app.ml.forecast.forecast_next_hours().

    Returns a list of {"category": ..., "message": ...} dicts.
    """
    if not forecast_points:
        return []

    recommendations = []

    sorted_points = sorted(forecast_points, key=lambda p: p["predicted_kwh"], reverse=True)
    peak_points = sorted_points[:3]
    off_peak_points = sorted(forecast_points, key=lambda p: p["predicted_kwh"])[:3]

    peak_hours = sorted(p["timestamp"].strftime("%-I%p").lower() for p in peak_points)
    off_peak_hours = sorted(p["timestamp"].strftime("%-I%p").lower() for p in off_peak_points)

    recommendations.append({
        "category": "peak_shift",
        "message": (
            f"Predicted peak demand around {', '.join(peak_hours)}. "
            f"Consider shifting flexible high-load activities (laundry, dishwasher, EV charging) "
            f"to lower-demand hours such as {', '.join(off_peak_hours)}."
        ),
    })

    daily_total = sum(p["predicted_kwh"] for p in forecast_points[:24])
    budget = settings.daily_budget_kwh

    if budget:
        if daily_total > budget * 1.1:
            recommendations.append({
                "category": "threshold_alert",
                "message": (
                    f"Predicted consumption for the next 24 hours ({daily_total:.1f} kWh) is "
                    f"{((daily_total / budget) - 1) * 100:.0f}% above your daily budget of "
                    f"{budget:.1f} kWh. Reducing usage during the predicted peak hours above "
                    f"would help bring this back under budget."
                ),
            })
        elif daily_total < budget * 0.7:
            recommendations.append({
                "category": "efficiency",
                "message": (
                    f"Predicted consumption for the next 24 hours ({daily_total:.1f} kWh) is "
                    f"comfortably under your {budget:.1f} kWh daily budget - no action needed."
                ),
            })

    # General efficiency tip when the peak/off-peak gap is large, since that
    # gap is exactly what load-shifting would help flatten.
    peak_avg = sum(p["predicted_kwh"] for p in peak_points) / len(peak_points)
    off_peak_avg = sum(p["predicted_kwh"] for p in off_peak_points) / len(off_peak_points)
    if off_peak_avg > 0 and (peak_avg / off_peak_avg) > 2.5:
        recommendations.append({
            "category": "efficiency",
            "message": (
                f"Peak-hour usage is over {peak_avg / off_peak_avg:.1f}x higher than your "
                f"lowest-demand hours. Flattening this gap (e.g. with a programmable thermostat "
                f"schedule or delayed-start appliances) tends to reduce both cost and grid strain."
            ),
        })

    return recommendations
