"""Endpoints for viewing trained-model comparison metrics and triggering retraining."""
import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.db_models import Reading
from app.ml.train import train_and_evaluate, METRICS_PATH

router = APIRouter(prefix="/api/models", tags=["models"])


@router.get("/metrics")
def get_model_metrics():
    """Returns the comparison table (MAE/RMSE/MAPE/R2) from the last training run."""
    if not METRICS_PATH.exists():
        raise HTTPException(
            status_code=404,
            detail="No training run found yet. Run `python scripts/train_models.py` first.",
        )
    return json.loads(Path(METRICS_PATH).read_text())


@router.post("/retrain")
def retrain(db: Session = Depends(get_db)):
    """
    Retrains all candidate models on whatever readings currently exist in the
    database, and re-selects the active model. Useful after enough new live
    readings have accumulated to be worth learning from.
    """
    import pandas as pd

    readings = db.query(Reading).order_by(Reading.timestamp).all()
    if len(readings) < 24 * 14:  # need at least ~2 weeks of hourly data for the 168h lag feature
        raise HTTPException(
            status_code=400,
            detail=f"Need at least {24*14} readings to retrain (have {len(readings)}). "
                   f"Run scripts/train_models.py to seed historical data first.",
        )

    df = pd.DataFrame([{
        "timestamp": r.timestamp,
        "consumption_kwh": r.consumption_kwh,
        "voltage": r.voltage,
        "current": r.current,
        "temperature_c": r.temperature_c,
    } for r in readings])

    summary = train_and_evaluate(df)
    return summary
