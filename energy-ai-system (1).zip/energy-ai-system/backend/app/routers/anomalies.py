"""Endpoint for browsing recently flagged anomalies."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database import get_db
from app.models.db_models import Anomaly
from app.schemas.schemas import AnomalyOut

router = APIRouter(prefix="/api/anomalies", tags=["anomalies"])


@router.get("", response_model=list[AnomalyOut])
def get_anomalies(limit: int = 50, db: Session = Depends(get_db)):
    return (
        db.query(Anomaly)
        .order_by(desc(Anomaly.timestamp))
        .limit(limit)
        .all()
    )
