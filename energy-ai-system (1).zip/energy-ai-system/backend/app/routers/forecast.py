"""Endpoint for retrieving a multi-hour-ahead consumption forecast."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.ml.forecast import forecast_next_hours
from app.routers.readings import _recent_readings_df
from app.schemas.schemas import ForecastResponse, ForecastPoint

router = APIRouter(prefix="/api/forecast", tags=["forecast"])


@router.get("", response_model=ForecastResponse)
def get_forecast(horizon: int = None, db: Session = Depends(get_db)):
    horizon_hours = horizon or settings.forecast_horizon_hours

    recent = _recent_readings_df(db, hours=24 * 8)
    if len(recent) < 2:
        raise HTTPException(
            status_code=404,
            detail="Not enough historical readings to forecast yet. Run scripts/train_models.py "
                   "to seed historical data, or record a few readings first.",
        )

    try:
        points, model_name = forecast_next_hours(recent, horizon_hours=horizon_hours)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    daily_total = sum(p["predicted_kwh"] for p in points[:24])
    peak = max(points, key=lambda p: p["predicted_kwh"]) if points else None

    return ForecastResponse(
        model_name=model_name,
        horizon_hours=horizon_hours,
        generated_at=datetime.now(timezone.utc).replace(tzinfo=None),
        points=[ForecastPoint(**p) for p in points],
        predicted_daily_total_kwh=round(daily_total, 3),
        predicted_peak_hour=peak["timestamp"] if peak else None,
        predicted_peak_kwh=peak["predicted_kwh"] if peak else None,
    )
