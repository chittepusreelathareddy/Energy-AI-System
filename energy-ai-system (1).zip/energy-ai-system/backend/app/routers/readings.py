"""
Endpoints for ingesting and browsing energy readings.

POST /api/readings accepts data from three sources, all going through the
same code path: the dashboard's own "record a reading" action, a real
IoT smart meter (identified via the x-device-key header), or
scripts/simulate_meter.py acting as a stand-in for real hardware. Every
new reading is immediately checked against the active model for anomalies,
so the anomaly feed stays up to date without a separate background job.
"""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.config import settings
from app.database import get_db
from app.models.db_models import Reading, Anomaly
from app.schemas.schemas import ReadingIn, ReadingOut, ReadingIngestResponse
from app.ml.forecast import forecast_next_hours
from app.ml.anomaly import check_anomaly

router = APIRouter(prefix="/api/readings", tags=["readings"])


@router.post("", response_model=ReadingIngestResponse, status_code=201)
def ingest_reading(
    payload: ReadingIn,
    db: Session = Depends(get_db),
    x_device_key: str | None = Header(default=None),
):
    """
    Accepts a new reading. If x-device-key is provided, it must match
    DEVICE_API_KEY (this is how a real IoT meter would authenticate); if
    omitted entirely, the reading is treated as coming from the dashboard
    itself (e.g. a manual "simulate reading" click), which needs no device key.
    """
    if x_device_key is not None and x_device_key != settings.device_api_key:
        raise HTTPException(status_code=401, detail="Invalid device key")

    timestamp = payload.timestamp or datetime.now(timezone.utc).replace(tzinfo=None)

    reading = Reading(
        timestamp=timestamp,
        consumption_kwh=payload.consumption_kwh,
        voltage=payload.voltage,
        current=payload.current,
        temperature_c=payload.temperature_c,
        source=payload.source,
    )
    db.add(reading)
    db.commit()
    db.refresh(reading)

    # Check this reading against the model's expectation for this hour, if
    # a trained model is available yet.
    anomaly_detected = False
    anomaly_message = None
    try:
        recent = _recent_readings_df(db, hours=24 * 8)
        if len(recent) >= 2:
            points, _ = forecast_next_hours(recent.iloc[:-1], horizon_hours=1)
            predicted = points[0]["predicted_kwh"] if points else None
            if predicted is not None:
                result = check_anomaly(payload.consumption_kwh, predicted)
                anomaly_detected = result["is_anomaly"]
                anomaly_message = result["message"]
                if anomaly_detected:
                    db.add(Anomaly(
                        timestamp=timestamp,
                        actual_kwh=payload.consumption_kwh,
                        predicted_kwh=predicted,
                        residual=result["residual"],
                        severity=result["severity"],
                        message=result["message"],
                    ))
                    db.commit()
    except FileNotFoundError:
        pass  # no trained model yet - skip anomaly check rather than failing the request

    return ReadingIngestResponse(
        reading=ReadingOut.model_validate(reading),
        anomaly_detected=anomaly_detected,
        anomaly_message=anomaly_message,
    )


@router.get("/history", response_model=list[ReadingOut])
def get_history(hours: int = 168, db: Session = Depends(get_db)):
    """Returns the most recent `hours` worth of readings, oldest first (for charting)."""
    readings = (
        db.query(Reading)
        .order_by(desc(Reading.timestamp))
        .limit(hours)
        .all()
    )
    return list(reversed(readings))


def _recent_readings_df(db: Session, hours: int = 24 * 8):
    """Helper: pulls recent readings into a pandas DataFrame for the ML modules."""
    import pandas as pd

    readings = (
        db.query(Reading)
        .order_by(desc(Reading.timestamp))
        .limit(hours)
        .all()
    )
    readings = list(reversed(readings))
    return pd.DataFrame([{
        "timestamp": r.timestamp,
        "consumption_kwh": r.consumption_kwh,
        "temperature_c": r.temperature_c,
    } for r in readings])
