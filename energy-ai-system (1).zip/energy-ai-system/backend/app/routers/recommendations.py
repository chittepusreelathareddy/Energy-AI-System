"""
Endpoint for optimization recommendations, generated fresh from the current
forecast on every request (recommendations are cheap to compute and should
always reflect the latest forecast, so nothing is cached here).
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.ml.forecast import forecast_next_hours
from app.ml.optimize import generate_recommendations
from app.models.db_models import Recommendation
from app.routers.readings import _recent_readings_df
from app.schemas.schemas import RecommendationOut

router = APIRouter(prefix="/api/recommendations", tags=["recommendations"])


@router.get("", response_model=list[RecommendationOut])
def get_recommendations(db: Session = Depends(get_db)):
    recent = _recent_readings_df(db, hours=24 * 8)
    if len(recent) < 2:
        raise HTTPException(status_code=404, detail="Not enough historical readings yet.")

    try:
        points, _ = forecast_next_hours(recent, horizon_hours=settings.forecast_horizon_hours)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    recs = generate_recommendations(points)

    # Persist each freshly generated recommendation for the history/log, and
    # return the freshly created rows (with real ids and timestamps).
    saved = []
    for r in recs:
        row = Recommendation(category=r["category"], message=r["message"])
        db.add(row)
        db.flush()
        saved.append(row)
    db.commit()
    for row in saved:
        db.refresh(row)

    return saved
