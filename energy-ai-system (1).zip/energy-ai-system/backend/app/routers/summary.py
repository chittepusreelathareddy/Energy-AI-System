"""Single endpoint powering the dashboard's top-level summary cards."""
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.config import settings
from app.database import get_db
from app.models.db_models import Reading, Anomaly, ModelMetric
from app.ml.forecast import forecast_next_hours
from app.routers.readings import _recent_readings_df
from app.schemas.schemas import DashboardSummary

router = APIRouter(prefix="/api/summary", tags=["summary"])


@router.get("", response_model=DashboardSummary)
def get_summary(db: Session = Depends(get_db)):
    latest_reading = db.query(Reading).order_by(desc(Reading.timestamp)).first()

    since_midnight = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=None)
    today_total = (
        db.query(Reading)
        .filter(Reading.timestamp >= since_midnight)
        .all()
    )
    today_kwh = sum(r.consumption_kwh for r in today_total)

    predicted_next_24h = 0.0
    try:
        recent = _recent_readings_df(db, hours=24 * 8)
        if len(recent) >= 2:
            points, _ = forecast_next_hours(recent, horizon_hours=24)
            predicted_next_24h = sum(p["predicted_kwh"] for p in points)
    except FileNotFoundError:
        pass

    open_anomaly_count = (
        db.query(Anomaly)
        .filter(Anomaly.timestamp >= datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=1))
        .count()
    )

    active_model_row = (
        db.query(ModelMetric)
        .filter(ModelMetric.is_active == True)  # noqa: E712
        .order_by(desc(ModelMetric.trained_at))
        .first()
    )
    active_model_name = active_model_row.model_name if active_model_row else None
    if active_model_name is None:
        # Fall back to reading it directly from the ml_artifacts metrics file
        # (the ModelMetric table is a convenience mirror; the file is source of truth).
        try:
            import json
            from app.ml.train import METRICS_PATH
            active_model_name = json.loads(METRICS_PATH.read_text())["active_model"]
        except FileNotFoundError:
            active_model_name = None

    return DashboardSummary(
        active_model=active_model_name,
        today_consumption_kwh=round(today_kwh, 3),
        predicted_next_24h_kwh=round(predicted_next_24h, 3),
        open_anomaly_count=open_anomaly_count,
        latest_reading_time=latest_reading.timestamp if latest_reading else None,
        latest_reading_kwh=latest_reading.consumption_kwh if latest_reading else None,
        daily_budget_kwh=settings.daily_budget_kwh,
    )
