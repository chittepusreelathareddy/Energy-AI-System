"""
FastAPI application entry point. Wires together the database, CORS, and all
routers. Run with:  uvicorn app.main:app --reload
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, engine
from app.routers import readings, forecast, anomalies, recommendations, models, summary

# Creates tables on startup if they don't already exist. For a project this
# size, plain SQLAlchemy metadata.create_all() is simpler and more
# beginner-friendly than introducing a full migration tool (e.g. Alembic) -
# see the README if you outgrow this and need real migrations later.
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI-Based Energy Consumption Prediction and Optimization",
    description="Forecasting, anomaly detection, and optimization recommendations for energy consumption data.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.client_url],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(readings.router)
app.include_router(forecast.router)
app.include_router(anomalies.router)
app.include_router(recommendations.router)
app.include_router(models.router)
app.include_router(summary.router)


@app.get("/")
def health_check():
    return {"status": "ok", "message": "AI-Based Energy Consumption Prediction and Optimization API is running"}
