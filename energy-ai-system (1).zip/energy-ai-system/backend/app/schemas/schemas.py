"""
Pydantic schemas: define the shape of API requests/responses, separate from
the SQLAlchemy ORM models in app/models/db_models.py.
"""
from datetime import datetime
from pydantic import BaseModel, Field


class ReadingIn(BaseModel):
    """What a client (dashboard or IoT device) sends to POST /api/readings."""
    timestamp: datetime | None = None  # defaults to "now" if omitted
    consumption_kwh: float = Field(..., ge=0)
    voltage: float | None = None
    current: float | None = None
    temperature_c: float | None = None
    source: str = "live"


class ReadingOut(BaseModel):
    id: int
    timestamp: datetime
    consumption_kwh: float
    voltage: float | None
    current: float | None
    temperature_c: float | None
    source: str

    class Config:
        from_attributes = True


class ReadingIngestResponse(BaseModel):
    reading: ReadingOut
    anomaly_detected: bool
    anomaly_message: str | None = None


class ForecastPoint(BaseModel):
    timestamp: datetime
    predicted_kwh: float


class ForecastResponse(BaseModel):
    model_name: str
    horizon_hours: int
    generated_at: datetime
    points: list[ForecastPoint]
    predicted_daily_total_kwh: float
    predicted_peak_hour: datetime | None
    predicted_peak_kwh: float | None


class AnomalyOut(BaseModel):
    id: int
    timestamp: datetime
    actual_kwh: float
    predicted_kwh: float
    residual: float
    severity: str
    message: str

    class Config:
        from_attributes = True


class ModelMetricOut(BaseModel):
    model_name: str
    mae: float
    rmse: float
    mape: float
    r2: float
    is_active: bool
    trained_at: datetime

    class Config:
        from_attributes = True


class RecommendationOut(BaseModel):
    id: int
    category: str
    message: str
    created_at: datetime

    class Config:
        from_attributes = True


class DashboardSummary(BaseModel):
    active_model: str | None
    today_consumption_kwh: float
    predicted_next_24h_kwh: float
    open_anomaly_count: int
    latest_reading_time: datetime | None
    latest_reading_kwh: float | None
    daily_budget_kwh: float | None
