"""
Stand-in for a real IoT smart meter: periodically posts a synthetic "live"
reading to the running API, so you can see the dashboard update in real
time without owning any actual hardware. Conceptually the same role as the
simulate_meter.py script would play in an ESP32-based project, but here it
also demonstrates the x-device-key header a real smart meter would send.

Usage:
  python scripts/simulate_meter.py --url http://localhost:8000 --key YOUR_DEVICE_API_KEY

Requires the API server to already be running (`uvicorn app.main:app --reload`)
and `pip install requests` (included in requirements.txt).
"""
import argparse
import time
from datetime import datetime

import requests

parser = argparse.ArgumentParser()
parser.add_argument("--url", default="http://localhost:8000", help="Base URL of the running API")
parser.add_argument("--key", default="replace_this_with_a_long_random_device_key", help="DEVICE_API_KEY from backend/.env")
parser.add_argument("--interval", type=float, default=5.0, help="Seconds between simulated readings")
parser.add_argument("--count", type=int, default=0, help="Number of readings to send (0 = run forever)")
args = parser.parse_args()

print(f"Simulating a smart meter posting to {args.url}/api/readings every {args.interval}s "
      f"(Ctrl+C to stop)...")

sent = 0
while args.count == 0 or sent < args.count:
    hour = datetime.now().hour
    # Rough daily shape so simulated readings look plausible on the dashboard
    base = 1.0 + 0.7 * max(0, 1 - abs(hour - 8) / 3) + 1.0 * max(0, 1 - abs(hour - 19) / 3)

    import random
    consumption = round(base * random.uniform(0.85, 1.15), 3)
    voltage = round(230 + random.uniform(-2, 2), 2)
    current = round((consumption * 1000) / voltage, 3)
    temperature = round(20 + random.uniform(-3, 3), 2)

    payload = {
        "consumption_kwh": consumption,
        "voltage": voltage,
        "current": current,
        "temperature_c": temperature,
        "source": "simulated",
    }

    try:
        resp = requests.post(
            f"{args.url}/api/readings",
            json=payload,
            headers={"x-device-key": args.key},
            timeout=5,
        )
        resp.raise_for_status()
        result = resp.json()
        flag = " ANOMALY!" if result.get("anomaly_detected") else ""
        print(f"  Sent {consumption} kWh{flag}")
    except requests.RequestException as exc:
        print(f"  Failed to send reading: {exc}")

    sent += 1
    if args.count == 0 or sent < args.count:
        time.sleep(args.interval)

print(f"Done. Sent {sent} readings.")
