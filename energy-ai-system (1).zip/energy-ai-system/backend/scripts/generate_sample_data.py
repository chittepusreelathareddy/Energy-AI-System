"""
Standalone CLI: generates a synthetic household energy dataset and saves it
as data/sample_dataset.csv - useful if you want to inspect or plot the raw
data before it's loaded into the database, or to swap in your own CSV with
the same column layout.

Usage:  python scripts/generate_sample_data.py [--days 400]
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.ml.data_generator import generate_synthetic_dataset  # noqa: E402

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=400, help="Number of days of hourly data to generate")
    parser.add_argument("--out", default="data/sample_dataset.csv", help="Output CSV path")
    args = parser.parse_args()

    df = generate_synthetic_dataset(days=args.days)
    out_path = Path(__file__).resolve().parent.parent / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df)} rows to {out_path}")
