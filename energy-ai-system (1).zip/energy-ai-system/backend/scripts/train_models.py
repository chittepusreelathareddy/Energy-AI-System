"""
Main setup script - run this once before starting the API server for the
first time. It:
  1. Generates (or loads, if already generated) a synthetic historical
     energy dataset.
  2. Loads that history into the database as "historical" readings, so the
     dashboard has something to show immediately.
  3. Trains and evaluates all candidate forecasting models, saving the best
     one as the active model.
  4. Records each candidate's metrics in the model_metrics database table
     (mirroring the ml_artifacts/model_metrics.json file) so the dashboard's
     model-comparison view has data on first load.

To use your own real data instead of the synthetic generator, replace the
call to generate_synthetic_dataset() below with pd.read_csv("your_file.csv"),
keeping the same columns: timestamp, consumption_kwh, voltage, current, temperature_c.

Usage:  python scripts/train_models.py [--days 400]
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.database import Base, engine, SessionLocal  # noqa: E402
from app.models.db_models import Reading, ModelMetric  # noqa: E402
from app.ml.data_generator import generate_synthetic_dataset  # noqa: E402
from app.ml.train import train_and_evaluate  # noqa: E402


def seed_readings(db, df):
    existing = db.query(Reading).count()
    if existing > 0:
        print(f"Database already has {existing} readings - skipping historical seed "
              f"(delete energy_ai.db to start fresh).")
        return

    print(f"Seeding {len(df)} historical readings into the database...")
    for _, row in df.iterrows():
        db.add(Reading(
            timestamp=row["timestamp"],
            consumption_kwh=float(row["consumption_kwh"]),
            voltage=float(row["voltage"]),
            current=float(row["current"]),
            temperature_c=float(row["temperature_c"]),
            source="historical",
        ))
    db.commit()
    print("Done seeding readings.")


def record_model_metrics(db, summary):
    db.query(ModelMetric).update({ModelMetric.is_active: False})
    for name, metrics in summary["results"].items():
        db.add(ModelMetric(
            model_name=name,
            mae=metrics["mae"],
            rmse=metrics["rmse"],
            mape=metrics["mape"],
            r2=metrics["r2"],
            is_active=(name == summary["active_model"]),
        ))
    db.commit()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=400, help="Days of synthetic history to generate")
    args = parser.parse_args()

    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    print(f"Generating {args.days} days of synthetic historical data...")
    df = generate_synthetic_dataset(days=args.days)

    seed_readings(db, df)

    print("\nTraining and evaluating candidate models...")
    summary = train_and_evaluate(df)
    record_model_metrics(db, summary)

    print(f"\nSetup complete. Active model: {summary['active_model']}")
    print("You can now start the API server with:  uvicorn app.main:app --reload")

    db.close()
