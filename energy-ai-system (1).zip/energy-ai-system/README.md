# AI-Based Energy Consumption Prediction and Optimization

A full-stack system that predicts future energy consumption, detects
peak-demand periods and unusual usage, and generates optimization
recommendations — with a live dashboard and an optional IoT-style ingestion
endpoint for real or simulated smart-meter data.

**Stack:** Python + FastAPI (backend) · SQLite via SQLAlchemy (swappable to
MySQL/Postgres) · scikit-learn + XGBoost for forecasting · React (Vite) +
Tailwind CSS + Chart.js (dashboard)

---

## 1. What this is, concretely

- A **forecasting module** that trains Random Forest and XGBoost models on
  hourly energy readings and predicts consumption 24 hours ahead, selecting
  whichever model scores best on MAE/RMSE/MAPE/R² (an optional LSTM baseline
  is also included — see Section 6).
- An **anomaly detection module** that flags any reading whose actual
  consumption deviates too far from what the model expected for that hour.
- An **optimization module** that turns the forecast into plain-language
  recommendations: predicted peak hours to shift load away from, and budget
  alerts if predicted usage is trending over a configured daily limit.
- A **dashboard** showing live status, historical and forecasted consumption
  charts, an anomaly feed, recommendations, and a model comparison table —
  with a "Simulate Reading" button so you can see the whole system react
  without owning any real hardware.
- An **IoT-style ingestion endpoint** (`POST /api/readings`) that a real
  smart meter, or the included `scripts/simulate_meter.py`, can post to.

This system ships with a **synthetic data generator** so it works
immediately without needing to source a real dataset first — see Section 7
for swapping in real data (e.g. the UCI household power dataset).

---

## 2. What you need installed first

### Python
Install Python 3.10+ from https://www.python.org/downloads/. Confirm with:
```
python3 --version
```

### Node.js (for the dashboard)
Install the **LTS** version from https://nodejs.org. Confirm with:
```
node -v
npm -v
```

No database installation is required — the project uses SQLite by default,
which is just a local file. See Section 8 if you want to switch to MySQL.

---

## 3. Project structure

```
energy-ai-system/
├── backend/
│   ├── app/
│   │   ├── main.py                 # FastAPI app entry point
│   │   ├── config.py                # Settings (.env)
│   │   ├── database.py              # SQLAlchemy engine/session
│   │   ├── models/db_models.py     # Reading, Anomaly, ModelMetric, Recommendation
│   │   ├── schemas/schemas.py      # Pydantic request/response schemas
│   │   ├── ml/
│   │   │   ├── data_generator.py   # Synthetic household energy dataset
│   │   │   ├── preprocessing.py    # Cleaning + time/lag/rolling feature engineering
│   │   │   ├── train.py             # Trains & compares Random Forest / XGBoost
│   │   │   ├── train_lstm.py       # Optional LSTM baseline (needs `pip install torch`)
│   │   │   ├── forecast.py          # Multi-hour-ahead autoregressive forecasting
│   │   │   ├── anomaly.py           # Residual-based anomaly detection
│   │   │   └── optimize.py          # Rule-based recommendation generation
│   │   └── routers/                 # readings, forecast, anomalies, recommendations, models, summary
│   ├── scripts/
│   │   ├── generate_sample_data.py # Standalone CSV generator
│   │   ├── train_models.py         # Seeds DB + trains models (run this first!)
│   │   └── simulate_meter.py       # Simulates a live IoT smart meter over HTTP
│   ├── ml_artifacts/                 # Saved trained model + metrics (generated)
│   └── requirements.txt
└── frontend/
    └── src/
        ├── services/energyService.js  # API calls
        ├── context/ThemeContext.jsx   # Dark mode
        ├── components/                 # Sidebar, Topbar, StatCard, etc.
        └── pages/                      # Dashboard, History, Anomalies, Recommendations, Models
```

### Data model

| Table | Purpose |
|---|---|
| `readings` | Every energy measurement — historical (seeded), simulated, or live |
| `anomalies` | Readings flagged as deviating too far from the model's prediction |
| `model_metrics` | MAE/RMSE/MAPE/R² for each trained candidate model, and which is active |
| `recommendations` | Generated optimization suggestions, logged over time |

### REST API reference

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/readings` | Ingest a new reading (dashboard or IoT device via `x-device-key` header) |
| GET | `/api/readings/history?hours=168` | Recent readings for charting |
| GET | `/api/forecast?horizon=24` | Multi-hour-ahead forecast from the active model |
| GET | `/api/anomalies?limit=50` | Recently flagged anomalies |
| GET | `/api/recommendations` | Fresh recommendations from the current forecast |
| GET | `/api/models/metrics` | Comparison table from the last training run |
| POST | `/api/models/retrain` | Retrain all candidate models on current DB data |
| GET | `/api/summary` | Dashboard summary stats |

Interactive API docs are auto-generated by FastAPI at `http://localhost:8000/docs` once the backend is running.

---

## 4. Local setup, step by step

Unzip the project, e.g. into `Documents/energy-ai-system`.

### Step 1 — Backend

```bash
cd energy-ai-system/backend
python3 -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

The default `.env` values work out of the box (SQLite, no external services
needed). Open it if you want to change the device key or daily energy budget.

**Seed the database and train the models** (this generates ~400 days of
synthetic hourly data, loads it into the database, and trains/evaluates
Random Forest and XGBoost):
```bash
python scripts/train_models.py
```
You should see per-model MAE/RMSE/MAPE/R² printed, and a line confirming
which model was selected as active.

**Start the API server:**
```bash
uvicorn app.main:app --reload
```
Visit `http://localhost:8000` — you should see a JSON status message. Visit
`http://localhost:8000/docs` for interactive API documentation.

### Step 2 — Frontend

Open a **new terminal**, keeping the backend running:
```bash
cd energy-ai-system/frontend
npm install
cp .env.example .env
npm run dev
```
Open the printed URL, typically `http://localhost:5173`.

### Step 3 — Try it out

1. The dashboard loads with historical data already charted (from the seed script) and a 24-hour forecast.
2. Click **Simulate Reading** a few times — watch the "Recent consumption" chart update.
3. Go to **Model Comparison** to see the MAE/RMSE/MAPE/R² table, and try **Retrain on latest data**.
4. Go to **Recommendations** to see peak-shift and budget suggestions generated from the current forecast.
5. To see an anomaly: the simulate button uses realistic values, so anomalies are rare from it alone — but you can trigger one directly:
   ```bash
   curl -X POST http://localhost:8000/api/readings \
     -H "Content-Type: application/json" \
     -d '{"consumption_kwh": 9.0, "source": "simulated"}'
   ```
   Then check the **Anomalies** page.

### Step 4 — Simulate a real IoT device (optional)

With the backend running, in another terminal:
```bash
cd energy-ai-system/backend
source venv/bin/activate
python scripts/simulate_meter.py --key YOUR_DEVICE_API_KEY --interval 5
```
`YOUR_DEVICE_API_KEY` must match `DEVICE_API_KEY` in `backend/.env`. Watch
the dashboard update in near-real-time as it posts readings, the same way a
real smart meter would.

---

## 5. Evaluation methodology

Random Forest and XGBoost are trained on a chronological 80/20 split (no
shuffling — the test set is always the most recent 20% of the series, so the
evaluation reflects genuine forecasting rather than interpolation). Both are
scored on:
- **MAE** — average error in kWh
- **RMSE** — penalizes larger misses more heavily
- **MAPE** — error as a percentage of actual usage (used to pick the "best" model)
- **R²** — proportion of variance explained

The model with the lowest test-set MAPE is saved as the active model. The
anomaly detector's threshold (mean + 3 standard deviations of absolute
residual) is computed from the training set's residuals, saved alongside the
model, and reused by both the ingestion endpoint and any manual anomaly
check.

---

## 6. Enabling the LSTM baseline (optional)

By default, only Random Forest and XGBoost are trained — both are fast and
need no extra heavy dependencies. To also compare against an LSTM:
```bash
pip install torch
```
Then re-run `python scripts/train_models.py` (or hit `POST /api/models/retrain`).
`app/ml/train.py` automatically detects torch and adds `LSTMForecaster` from
`app/ml/train_lstm.py` to the comparison — no code changes needed.

---

## 7. Using real data instead of synthetic data

The synthetic generator (`app/ml/data_generator.py`) exists so the whole
pipeline works immediately, but it's not a substitute for real consumption
patterns. To use a real dataset (e.g. the
[UCI Individual Household Electric Power Consumption dataset](https://archive.ics.uci.edu/dataset/235)):

1. Get your data into a CSV with these columns: `timestamp, consumption_kwh, voltage, current, temperature_c` (temperature can be pulled from a weather API/archive if not already in your data).
2. In `scripts/train_models.py`, replace the `generate_synthetic_dataset(...)` call with `pd.read_csv("your_file.csv")`.
3. Delete `backend/energy_ai.db` and re-run `python scripts/train_models.py` to reseed with real data.

---

## 8. Switching from SQLite to MySQL

SQLite needs zero setup, which is why it's the default. To use MySQL instead:
```bash
pip install pymysql
```
Then update `DATABASE_URL` in `backend/.env`:
```
DATABASE_URL=mysql+pymysql://user:password@localhost:3306/energy_ai
```
No other code changes are needed — SQLAlchemy handles the rest.

---

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| `No trained model found` errors | Run `python scripts/train_models.py` from the `backend` folder first. |
| Frontend shows network errors | Confirm the backend terminal is still running and `VITE_API_URL` in `frontend/.env` matches its port. |
| `simulate_meter.py` gets 401 errors | Its `--key` must exactly match `DEVICE_API_KEY` in `backend/.env`. |
| Retrain fails with "Need at least N readings" | You need roughly 2+ weeks of hourly data for the 168-hour lag feature — the seed script provides this by default; a fresh live-only deployment needs to accumulate history first. |
| CORS errors in the browser console | Make sure `CLIENT_URL` in `backend/.env` matches the URL your frontend actually runs on. |

---

## 10. Limitations and future scope

- The synthetic dataset is a reasonable stand-in for demonstrating the
  pipeline, but real deployments should validate against actual local
  consumption data before trusting forecasts operationally.
- The anomaly threshold is a simple statistical default; sites with highly
  variable usage may want to tune it (see `app/ml/train.py`'s
  `residual_stats` calculation).
- The forecast holds temperature constant across the forecast horizon as a
  simplification; integrating a real weather forecast API would likely
  improve accuracy for temperature-sensitive loads (heating/cooling).
- IoT integration here is HTTP + a shared device key, which is fine for a
  prototype; a production deployment should use HTTPS, per-device keys, and
  rate limiting (see the note in `app/routers/readings.py`).
- Recommendations are intentionally rule-based and explainable rather than
  another opaque model — future work could explore automated demand-response
  actions rather than just suggestions.
